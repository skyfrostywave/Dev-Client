# Dev Client

A Minecraft Fabric 1.21.11 client-side starter focused on a premium ClickGUI,
client configuration, HUD utilities, and authorized server testing.

## Requirements
- Java 21
- Minecraft 1.21.11
- Fabric Loader
- Fabric API

## Build
```bash
./gradlew build
```
Windows:
```bat
gradlew.bat build
```

The built mod jar is located in `build/libs/`.

## Controls
- Right Shift: open/close ClickGUI
- GUI: click module cards to toggle prototype module states
- `L`: toggle Light Level UI state
- `C`: toggle Chunk Viewer UI state

## Included
- Neon-red ClickGUI
- Category tabs
- Module toggles
- Basic config persistence
- Client keybinds
- Placeholder utility module state

This starter intentionally contains UI/state scaffolding only. It does not implement
combat automation, hidden-ore X-ray, player tracking, or server bypass functionality.
