package com.devclient.config;

import com.devclient.DevClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("devclient.json");

    public boolean lightLevel = true;
    public boolean chunkViewer = false;
    public boolean hud = true;
    public boolean serverDiagnostics = false;
    public boolean ignoreSunlight = true;
    public float overlayOpacity = 0.75f;
    public int chunkRadius = 8;
    public String accentColor = "#ff2020";

    public static ClientConfig load() {
        try {
            if (Files.exists(FILE)) {
                ClientConfig loaded = GSON.fromJson(Files.readString(FILE), ClientConfig.class);
                return loaded != null ? loaded : new ClientConfig();
            }
        } catch (Exception ignored) {
        }
        return new ClientConfig();
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (Exception e) {
            System.err.println("[Dev Client] Could not save config: " + e.getMessage());
        }
    }
}
