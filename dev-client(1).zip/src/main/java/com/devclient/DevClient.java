package com.devclient;

import com.devclient.config.ClientConfig;
import com.devclient.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class DevClient implements ClientModInitializer {
    public static final String MOD_ID = "devclient";
    public static ClientConfig CONFIG = ClientConfig.load();

    private static KeyBinding openGui;
    private static KeyBinding lightLevel;
    private static KeyBinding chunkViewer;

    @Override
    public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.devclient.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create("Dev Client")
        ));
        lightLevel = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.devclient.light_level",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_L,
                KeyBinding.Category.create("Dev Client")
        ));
        chunkViewer = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.devclient.chunk_viewer",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                KeyBinding.Category.create("Dev Client")
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                } else if (client.currentScreen instanceof ClickGuiScreen) {
                    client.setScreen(null);
                }
            }
            while (lightLevel.wasPressed()) {
                CONFIG.lightLevel = !CONFIG.lightLevel;
                CONFIG.save();
            }
            while (chunkViewer.wasPressed()) {
                CONFIG.chunkViewer = !CONFIG.chunkViewer;
                CONFIG.save();
            }
        });
    }
}
