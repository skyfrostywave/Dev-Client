package com.devclient.gui;

import com.devclient.DevClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int RED = 0xFFFF2020;
    private static final int PANEL = 0xFF101010;
    private static final int CARD = 0xFF181818;
    private static final int TEXT = 0xFFEAEAEA;
    private static final int MUTED = 0xFF888888;

    private String category = "Visuals";
    private final List<ButtonWidget> moduleButtons = new ArrayList<>();

    public ClickGuiScreen() {
        super(Text.literal("Dev Client"));
    }

    @Override
    protected void init() {
        moduleButtons.clear();
        int panelX = width / 2 - 170;
        int panelY = height / 2 - 120;
        int panelW = 340;

        String[] tabs = {"Combat", "Visuals", "World", "Player", "Utility", "Settings"};
        int tabW = 54;
        for (int i = 0; i < tabs.length; i++) {
            final String tab = tabs[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(tab), b -> {
                category = tab;
                clearAndInit();
            }).dimensions(panelX + 10 + i * (tabW + 1), panelY + 45, tabW, 20).build());
        }

        List<String> modules = switch (category) {
            case "Visuals" -> List.of("Light Level", "HUD");
            case "World" -> List.of("Chunk Viewer", "Server Diagnostics");
            case "Player" -> List.of("Free Cam (test UI)");
            case "Utility" -> List.of("Keybind Manager", "Config Manager");
            case "Combat" -> List.of("Combat Testing (disabled prototype)");
            default -> List.of("Accent: Neon Red", "Reset Config");
        };

        int y = panelY + 76;
        for (String name : modules) {
            boolean enabled = moduleEnabled(name);
            ButtonWidget button = ButtonWidget.builder(
                    Text.literal(name + "  [" + (enabled ? "ON" : "OFF") + "]"),
                    b -> toggle(name)
            ).dimensions(panelX + 16, y, panelW - 32, 24).build();
            addDrawableChild(button);
            moduleButtons.add(button);
            y += 29;
        }
    }

    private boolean moduleEnabled(String name) {
        return switch (name) {
            case "Light Level" -> DevClient.CONFIG.lightLevel;
            case "HUD" -> DevClient.CONFIG.hud;
            case "Chunk Viewer" -> DevClient.CONFIG.chunkViewer;
            case "Server Diagnostics" -> DevClient.CONFIG.serverDiagnostics;
            default -> false;
        };
    }

    private void toggle(String name) {
        switch (name) {
            case "Light Level" -> DevClient.CONFIG.lightLevel = !DevClient.CONFIG.lightLevel;
            case "HUD" -> DevClient.CONFIG.hud = !DevClient.CONFIG.hud;
            case "Chunk Viewer" -> DevClient.CONFIG.chunkViewer = !DevClient.CONFIG.chunkViewer;
            case "Server Diagnostics" -> DevClient.CONFIG.serverDiagnostics = !DevClient.CONFIG.serverDiagnostics;
            case "Reset Config" -> DevClient.CONFIG = new com.devclient.config.ClientConfig();
            default -> {
                // UI-only prototype modules intentionally do not activate game mechanics.
            }
        }
        DevClient.CONFIG.save();
        clearAndInit();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int x = width / 2 - 170;
        int y = height / 2 - 120;
        int w = 340;
        int h = 240;

        context.fill(x - 1, y - 1, x + w + 1, y + h + 1, RED);
        context.fill(x, y, x + w, y + h, PANEL);
        context.fill(x, y, x + w, y + 36, 0xFF1A0909);
        context.drawText(textRenderer, "DEV CLIENT", x + 14, y + 12, RED, true);
        context.drawText(textRenderer, "1.21.11  |  TEST UI", x + w - 130, y + 12, MUTED, false);
        context.fill(x + 10, y + 39, x + w - 10, y + 40, 0xFF552020);

        context.fill(x + 12, y + 70, x + w - 12, y + h - 10, CARD);
        context.drawText(textRenderer, category.toUpperCase(), x + 20, y + 76, TEXT, true);
        context.drawText(textRenderer, "Client configuration prototype", x + 20, y + 91, MUTED, false);
        context.drawText(textRenderer, "Right Shift: close GUI", x + 14, y + h - 18, MUTED, false);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
